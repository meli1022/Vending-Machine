package cp213;

import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

/**
 * Main class for the Vending Machine.
 *
 * @author Melissa Pinto
 * @version 2021-03-19
 */
public class A05Main {

    public static void main(String[] args) {
	
	new VendView();
	
    }

}